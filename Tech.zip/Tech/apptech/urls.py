# from django.urls import path
# from . import views
# from .views import Thankyouview, homeview, collageview, collageFormview, collageListview, collageDetailview
#
# app_Name = 'apptech'
#
#
# urlpatterns = [
#     # path('App/', views.members, name='members'),
#     path('college/', collageFormview.as_view(), name='college'),
#     path('thankyou/<int:pk>/', Thankyouview.as_view(), name='Thankyou'),
#     path('home/', homeview.as_view(), name='home'),
#     path('collage/', collageview.as_view(), name='collage'),
#     path('list/', collageListview.as_view(), name='collagelist'),
#     path('detail_collage/<int:pk>/', collageDetailview.as_view(), name='detail_collage')
# ]




from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from .views import DetailView


app_name = 'apptech'

urlpatterns = [
    # path('rental/', views.rental_view),
    # path('', views. Street_view),
    # path('picture/', PictureFormView.as_views(), name='Picture'),
    # path('', views.img_base64),
    path('detect/', views.detect_labels),
    path('', views.Upload_image),
    # path('delete_image/(?P<pk>\d+)/', views.delete_image, name='delete_image'),
    # path('home/', views.home),

]
# if settings.DEBUG:
#      urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
