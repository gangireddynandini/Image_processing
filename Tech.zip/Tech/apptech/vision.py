import os, io
from google.cloud import vision

def detect_labels():
    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = r'AIzaSyAUagsoKIAWtGt9_6q-fzKWwd8wD-wfFQM'

    client = vision.ImageAnnotatorClient()

    file_name = 'image7'
    image_path = r'C:\djangoproject\Tech\static\images7.jpg'

    with io.open(image_path, 'rb') as image_file:
        content = image_file.read()

    image = vision.Image(content=content)
    response = client.label_detection(image=image)
    labels = response.label_annotations
    print(labels)


