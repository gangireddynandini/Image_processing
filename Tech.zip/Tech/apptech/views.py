# from django.shortcuts import render
# from django.http import HttpResponse
# from django.views.generic import TemplateView, FormView, CreateView, ListView, DetailView
# from django.urls import reverse_lazy, reverse
# from apptech.forms import collageForm
# from  .models import collage
#
#
# # def members(request):
# #     return HttpResponse("Hello world!")
#
# class collageFormview(FormView):
#     form_class = collageForm
#     template_name = 'collegeForm.html'
    # success_url = reverse_lazy('Thankyou')
    # success_url = "/apptech/Thankyou/"

    # def form_valid(self, form):
    #     print(form.cleaned_data)
    #     return super().form_valid(form)
#
# class Thankyouview(TemplateView):
#     template_name = 'Thankyou.html'
#
# class homeview(TemplateView):
#     template_name = 'home.html'
#
# class collageview(CreateView):
#     model = collage
#     fields = "__all__"
#     template_name = 'collegeForm.html'
#     success_url = reverse_lazy('Thankyou')
#
# class collageListview(ListView):
#     model = collage
#     template_name = 'collagelist.html'
#     # context_object_name = 'collagelist'
#
#
# class collageDetailview(DetailView):
#     model = collage
#     template_name = 'index.html'
#     # template_name = 'collageForm.html.html'
#     # template_name = 'Thankyou.html'






import os, io
from google.cloud import vision
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from .forms import Image_form
from .models import Upload_file
from google.cloud.vision_v1 import types
from django.shortcuts import render
from django.shortcuts import redirect
import base64
from PIL import Image
from io import BytesIO
from django.urls import reverse_lazy
from django.views.generic import TemplateView, DeleteView
from django.views.generic import DetailView
import pandas as pd



#
# def img_base64(image):
#     buff = BytesIO()
#     image.save(buff, format='JPEG')
#     img_str = base64.b64encode(buff.getvalue())
#     img_str = img_str.decode("utf-8")
#     return img_str
#
# def home(request):
#     image = Image.open('C:\djangoproject\Tech\static\image.jpg.jpg')
#     image64 = img_base64(image)
#     return render(request, 'index.html', {'image64': image64})


# def image_list(request):
#     images = Upload_file.objects.all()
#     return render(request, 'index.html', {'images': images})





def Upload_image(request):

    if request.method == 'POST':
        form = Image_form(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            instance = form.save()
            print(instance.File.path)
            result = detect_labels(instance.File.path)

            context = {
                'result': result,
                'form': Image_form,
                'file': instance.File.path
            #     # 'file': request.build_absolute_uri('/')[:-1] + '/Tech/static/' + '' + 'image.jpg.jpg'
            }

            return render(request, "index.html", context)
        else:
            print('FORM IS:', form)
            print('FORM ERROR:', form.errors)
            return render(request, 'failure.html')
    else:
        form = Image_form()
        return render(request, "index.html", {'form': form})



def detect_labels(filepath):
    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = r"C:\Users\DELL\Downloads\apuroop-project-a38bf389f82d.json"

    client = vision.ImageAnnotatorClient()

    # file_name = 'image5.jpg'
    # image_path = f'.\static\{file_name}'
    image_path = filepath
    # image_path = r'C:\djangoproject\Tech\static\image6.jpg'
    with io.open(image_path, 'rb') as image_file:
        content = image_file.read()

    image = vision.Image(content=content)
    response = client.label_detection(image=image)
    labels = response.label_annotations
    df = pd.DataFrame(columns=['description', 'score'])
    for label in labels:
        df = df.append(
             dict(
                    description=label.description,
                     score=label.score,
             ), ignore_index=True
        )
    print(response)
    print(df)
    return response




# import pandas as pd
#     df = pd.DataFrame(columns=['description', 'score'])
#     for label in labels:
#         df = df.append(
#             dict(
#                 description=label.description,
#                 score=label.score,
#             ), ignore_index=True
#         )
#     print(df)
# df = pd.DataFrame(columns=['description', 'score'])
# for label in labels:
#     df = df.append(
#          dict(
#             description=label.description,
#             score=label.score,
#         ),  ignore_index=True
#     )
# print(df)

# def detect_labels(filename):
#
#     os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = r"C:\djangoproject\djangoproject\madhu-project-374507-accdddf38b5e (1).json"
#
#     client = vision.ImageAnnotatorClient()
#
#     file_name = 'image7'
#     image_path = r'C:\djangoproject\Tech\static\images7.jpg'
#
#     with io.open(image_path, 'rb') as image_file:
#         content = image_file.read()
#
#     image = vision.Image(content=content)
#     response = client.label_detection(image=image)
#     print(response)
#     return render(request, "success.html",{} )

