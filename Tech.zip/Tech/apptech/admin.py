from django.contrib import admin
# admin.site.register(collage)
from .models import Upload_file
# Register your models here.

admin.site.register(Upload_file)