from django.db import models

class Upload_file(models.Model):
    File = models.ImageField(upload_to='C:\djangoproject\Tech\static')


