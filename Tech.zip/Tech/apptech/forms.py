from django.forms import forms, ModelForm
from .models import Upload_file

class Image_form(ModelForm):
    class Meta:
        model = Upload_file
        fields = ['File']


